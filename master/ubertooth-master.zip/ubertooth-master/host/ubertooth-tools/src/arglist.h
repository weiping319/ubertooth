int *
listOfInts (char *arg, int *n, int (*token_parser) (char *p, int *nchars));
